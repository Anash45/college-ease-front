<header class="navbar navbar-light sticky-top bg-light flex-md-nowrap p-0">
    <a class="navbar-brand col-md-4 order-md-1 order-2 col-lg-3 me-0 px-3 d-flex justify-content-between"
        href="dashboard.php">
        <img src="./assets/img/bricks.png" alt="Img" height="60"><img src="./assets/img/logo.png" alt="Img"
            height="60"></a>
    <button class="navbar-toggler order-1 d-md-none collapsed" type="button" data-bs-toggle="collapse"
        data-bs-target="#sidebarMenu" aria-controls="sidebarMenu" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="navbar-nav order-3 px-3">
        <div class="nav-item text-nowrap">
            <a class="btn btn-danger text-white rounded-5" href="logout.php"><i class="fal fa-sign-out"></i></a>
        </div>
    </div>
</header>