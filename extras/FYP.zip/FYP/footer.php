<footer>
    <div class="text-center">
        <img src="./assets/img/logo.png" alt="Logo" height="50">
        <p>&copy; 2024 - AES Clinic - All Rights Reserved</p>
    </div>
</footer>