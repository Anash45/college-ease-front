<header>
    <a href="index.php" class="h-link">
        <img src="./assets/img/logo.png" alt="Logo" height="60"><span>AES Clinic</span>
    </a>
    <ul class="h-list">
        <li><span>Hi, <?php echo $_SESSION['Name']; ?></span></li>
        <li><a href="logout.php">Logout</a></li>
    </ul>
</header>